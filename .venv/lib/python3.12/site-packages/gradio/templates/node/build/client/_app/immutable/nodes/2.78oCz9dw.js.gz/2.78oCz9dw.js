import { N, _ } from "../chunks/2.D9CcoDFK.js";
export {
  N as component,
  _ as universal
};
